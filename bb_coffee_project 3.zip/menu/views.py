"""Вьюхи для страницы меню"""
from django.views.generic import TemplateView
from .models import Category, MenuItem


class MenuView(TemplateView):
    """Страница меню с группировкой по категориям"""
    template_name = 'menu/menu.html'

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        # Загружаем все категории с позициями
        ctx['categories'] = Category.objects.prefetch_related('items').filter(
            items__is_available=True
        ).distinct()
        return ctx
